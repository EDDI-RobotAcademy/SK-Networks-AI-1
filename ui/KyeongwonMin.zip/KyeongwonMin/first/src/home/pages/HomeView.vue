<template>
    <p>이거시호미다</p>
</template>

<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
name: 'HomeView',

components: {
},
});
</script>
  