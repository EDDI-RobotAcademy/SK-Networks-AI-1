import HomeView from "@/home/pages/HomeView.vue"

const HomeRoutes = [
    {
        path: '/',
        name: 'HomeView',
        component: HomeView,
    },
]

export default HomeRoutes