export interface AccountState {
    isLoggedIn: boolean
}

const state: AccountState = {
    isLoggedIn: false
}

export default state