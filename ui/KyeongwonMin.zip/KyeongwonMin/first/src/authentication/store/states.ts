export interface AuthenticationState {
    isAuthenticated: boolean
}

const state: AuthenticationState = {
    isAuthenticated: false
}

export default state