class Dice:
    def roll(self):
        import random
        return random.randint(1,6) # 주사위숫자변경 확장성 고려하지않음


